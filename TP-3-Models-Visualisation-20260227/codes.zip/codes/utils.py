import keras
import numpy as np
import matplotlib.pyplot as plt 
import matplotlib.cm as cm
import tensorflow as tf


def display_activation(activation, col_size, row_size):
    print(activation.shape,'the shape')
    activation_index=0
    fig, ax = plt.subplots(row_size, col_size, figsize=(row_size*2.5,col_size*1.5))
    for row in range(0,row_size):
        for col in range(0,col_size):
            ax[row][col].imshow(activation[0, :, :, activation_index], cmap='viridis')
            ax[row][col].set_xticks([])
            ax[row][col].set_yticks([])
            activation_index += 1
    plt.show()
        

def plotImage(img_tensor):
    fig = plt.figure(figsize=(10,5))
    plt.imshow(img_tensor,cmap="gray")
    plt.axis('off')
    plt.show()
    
def plotImages(x,y):
    fig, axes = plt.subplots(5, 5, figsize=(10, 10))
    # Plot the images in a 5x5 grid
    for i in range(5):
        for j in range(5):
            # Select the image and label
            index = i * 5 + j
            axes[i, j].imshow(x[index], cmap='gray')
            axes[i, j].set_title(str(y[index]))
            axes[i, j].axis('off')
    
    plt.tight_layout()
    plt.show()
    

def plot_filter(filters, col_size, row_size):
    
    print(filters.shape,'the shape')
    f_ind=0
    fig, ax = plt.subplots(row_size, col_size, figsize=(row_size*2.5,col_size*1.5))
    for row in range(0,row_size):
        for col in range(0,col_size):
            ax[row][col].imshow(filters[:, :, 0, f_ind], cmap='gray')
            ax[row][col].set_xticks([])
            ax[row][col].set_yticks([])
            f_ind += 1
    plt.show()

def plot_loss(history):
    # Plotting Loss and Accuracy
    plt.figure(figsize=(12, 8))
    
    # Plot Loss
    plt.subplot(1, 2, 1)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Model Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    
    # Plot Accuracy
    plt.subplot(1, 2, 2)
    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.title('Model Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    
    plt.tight_layout()
    plt.show()



def superimpose_image(img_input, heatmap, cam_path = None,  alpha=0.01):
    
    # Load the original image
    img =img_input.reshape(28,28)
    img = keras.preprocessing.image.img_to_array(img)

    #Normalise to 255 values
    heatmap = np.uint8(255 * heatmap)
    jet = cm.get_cmap("jet")

    jet_colors = jet(np.arange(256))[:, :3]
    jet_heatmap = jet_colors[heatmap]
    jet_heatmap = keras.preprocessing.image.array_to_img(jet_heatmap)
    jet_heatmap = jet_heatmap.resize((img.shape[1], img.shape[0]))
    jet_heatmap = keras.preprocessing.image.img_to_array(jet_heatmap)

    superimposed_img = jet_heatmap * alpha + img
    superimposed_img = keras.preprocessing.image.array_to_img(superimposed_img)

    #Save the results to a file
    if cam_path is not None: 
        superimposed_img.save(cam_path)
    
    return superimposed_img

def superimpose_image_vgg(img_, heatmap, cam_path = None, alpha=0.4):
   
    img = keras.preprocessing.image.img_to_array(img_)
    # Rescale heatmap to a range 0-255
    heatmap = np.uint8(255 * heatmap)

    # Use jet colormap to colorize heatmap
    jet = cm.get_cmap("jet")

    # Use RGB values of the colormap
    jet_colors = jet(np.arange(256))[:, :3]
    jet_heatmap = jet_colors[heatmap]

    # Create an image with RGB colorized heatmap
    jet_heatmap = keras.preprocessing.image.array_to_img(jet_heatmap)
    jet_heatmap = jet_heatmap.resize((img.shape[1], img.shape[0]))
    jet_heatmap = keras.preprocessing.image.img_to_array(jet_heatmap)

    # Superimpose the heatmap on original image
    superimposed_img = jet_heatmap * alpha + img
    superimposed_img = keras.preprocessing.image.array_to_img(superimposed_img)
    
    # Save the superimposed image
    if cam_path is not None: 
        superimposed_img.save(cam_path)

    return superimposed_img
    # Display Grad CAM
    #display(Image(cam_path))
    




def calc_gradcam_heatmap(img_array, model, last_conv_layer_name, pred_index=None):
    # First, we create a model that maps the input image to the activations
    # of the last conv layer as well as the output predictions
    grad_model = tf.keras.models.Model(
        [model.input], [model.get_layer(last_conv_layer_name).output, model.output]
    )

    # Then, we compute the gradient of the top predicted class for our input image
    # with respect to the activations of the last conv layer
    with tf.GradientTape() as tape:
        last_conv_layer_output, preds = grad_model(img_array)
        if pred_index is None:
            pred_index = tf.argmax(preds[0])
        class_channel = preds[:, pred_index]

    # This is the gradient of the output neuron (top predicted or chosen)
    # with regard to the output feature map of the last conv layer
    grads = tape.gradient(class_channel, last_conv_layer_output)

    # This is a vector where each entry is the mean intensity of the gradient
    # over a specific feature map channel
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

    # We multiply each channel in the feature map array
    # by "how important this channel is" with regard to the top predicted class
    # then sum all the channels to obtain the heatmap class activation
    last_conv_layer_output = last_conv_layer_output[0]
    heatmap = last_conv_layer_output @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)

    # For visualization purpose, we will also normalize the heatmap between 0 & 1
    heatmap = tf.maximum(heatmap, 0) / tf.math.reduce_max(heatmap)
    return heatmap.numpy()
