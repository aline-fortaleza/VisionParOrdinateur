import keras
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt 

from tensorflow.keras.preprocessing.image    import img_to_array, load_img
from tensorflow.keras.applications.vgg16     import preprocess_input, decode_predictions
from utils import calc_gradcam_heatmap, superimpose_image_vgg



def get_pretrained_model():
    
    #Step 3 obtain the VGG 16 model 
    model_builder = tf.keras.applications.vgg16.VGG16
    
    #Step 4, obtain the preprocessor
    preprocess_input = keras.applications.vgg16.preprocess_input
    
    #Step 5, obtain label decoder
    decode_predictions = keras.applications.vgg16.decode_predictions
    
    return model_builder(weights="imagenet"), preprocess_input, decode_predictions


if __name__ == '__main__':

    #Step 1 get the model and some helpers by calling get_pretrained_model() function
    model, preprocessor, predictionDecoder = get_pretrained_model()
    
    #Step 6 print the model sumamry 
    model.summary()
    
    #Q1: why such architectures and which leayer to choose? 
    
    #Step 7 load an image (elephant.jpg example) and show the image 
    
    image_ = load_img('./elephant.jpg', target_size=(224, 224))
    
    plt.figure(figsize=(10,10))
    plt.imshow(image_)
    plt.show()

    #Step 8 Target a layer 
    last_conv_layer_name = "block5_conv3"
    
    #Preprocess the image by inputing it to an array, convert it to a numpy array,  and calling preprocessor.
    image = img_to_array(image_)
    image = preprocess_input(image)
    processed_images = np.array([image])
    
    #Step 9, do the prediction and print the associated label using predictionDecoder
    
    preds = model.predict(processed_images)
    print("Predicted:", predictionDecoder(preds, top=1)[0])
    
    #Step 10, make the gradcam heatmap by calling make_gradcam_heatmap() function and display the heatmap
    heatmap = calc_gradcam_heatmap(processed_images, model, last_conv_layer_name)
    
    # Display heatmap
    plt.matshow(heatmap)
    plt.show()
    
    #Step 11, show the heatmap on top of the original image
    plt.imshow(superimpose_image_vgg(image_, heatmap))
    plt.show()
    
    
    #Step 12, try another image of Cat and Dog
    image_= load_img('./cat_dog.jpg', target_size=(224, 224))
    image = img_to_array(image_)
    image = preprocess_input(image)
    
    processed_images = np.array([image])
    
    
    #https://github.com/anishathalye/imagenet-simple-labels/blob/master/imagenet-simple-labels.json
    
    #Step 13, try to target specific class (e.g. 260 of chow dog). full list can be seen in the list above. 
    #label = 260; #chow
    label = 285; #egyptian mau
    
    #label = 852; #television
    #label = 847; #table lamp
    
    #Step 13, make the grad cam and show the superimpose image 
    heatmap = calc_gradcam_heatmap(processed_images, model, last_conv_layer_name, pred_index=label)
    plt.imshow(superimpose_image_vgg(image_, heatmap))
    plt.show()
    
    #Exercise 1, try to take an image and change the target label and evaluate the model focus. 
    
    